using FamilyOS.Application.Common;
using FamilyOS.Application.Interfaces;
using FamilyOS.Domain.Approvals;
using FamilyOS.Domain.Calendar;
using FamilyOS.Domain.Common;
using FamilyOS.Domain.Execution;
using FamilyOS.Domain.Notifications;
using FamilyOS.Domain.Procurement;
using FamilyOS.Domain.Requests;
using FamilyOS.Domain.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace FamilyOS.Application.Requests;

public record PendingQuestionDto(Guid Id, string QuestionText, bool IsAnswered, string? Answer);

public record RequestHistoryDto(
    Guid Id, RequestStatus Status, Guid ActorMemberId, string Detail, DateTime TimestampUtc);

public record RequestDto(
    Guid Id, RequestTypeCode Type, RequestStatus Status, string Title, string? Summary,
    decimal? Amount, DateTime? NeededByUtc, Guid RequesterMemberId, string RequesterName,
    Guid? CurrentApproverMemberId, string? DenialReason, DateTime CreatedAtUtc,
    Dictionary<string, object?> Answers, Guid? ExecutionPlanId,
    List<PendingQuestionDto> PendingQuestions);

public record RequestTypeDto(Guid Id, RequestTypeCode Code, string Name, string? Description, List<QuestionDefinition> Questions);

public record CreateRequestCommand(
    RequestTypeCode Type, string Title, Dictionary<string, object?> Answers,
    decimal? Amount, DateTime? NeededBy
) : IRequest<RequestDto>;

public record UpdateDraftRequestCommand(
    Guid RequestId,
    string? Title,
    Dictionary<string, object?>? Answers,
    decimal? Amount,
    DateTime? NeededBy
) : IRequest<RequestDto>;

public record SubmitRequestCommand(Guid RequestId) : IRequest<RequestDto>;
public record AskQuestionCommand(Guid RequestId, string QuestionText) : IRequest<RequestDto>;
public record AnswerQuestionCommand(Guid RequestId, Guid QuestionId, string Answer) : IRequest<RequestDto>;
public record ApproveRequestCommand(Guid RequestId, bool Conditional = false) : IRequest<RequestDto>;
public record DenyRequestCommand(Guid RequestId, string Reason) : IRequest<RequestDto>;
public record CancelRequestCommand(Guid RequestId, string? Reason = null) : IRequest<RequestDto>;
public record GetRequestQuery(Guid RequestId) : IRequest<RequestDto>;
public record GetMyRequestsQuery() : IRequest<List<RequestDto>>;
public record GetApprovalQueueQuery() : IRequest<List<RequestDto>>;
public record GetRequestHistoryQuery(Guid RequestId) : IRequest<List<RequestHistoryDto>>;
public record GetRequestTypesQuery() : IRequest<List<RequestTypeDto>>;
public record EvaluatePolicyQuery(Guid RequestId) : IRequest<PolicyEvaluationResult>;

public record OverridePolicyCommand(
    Guid RequestId,
    bool Approve,
    string? Reason = null,
    bool Conditional = false
) : IRequest<RequestDto>;

public record GenerateExecutionPlanCommand(Guid RequestId) : IRequest<ExecutionPlanDto>;
public record CommitExecutionPlanCommand(Guid PlanId, List<Guid>? DeselectedItemIds) : IRequest<ExecutionPlanDto>;
public record ExecutionPlanDto(Guid Id, Guid RequestId, ExecutionPlanStatus Status, List<ExecutionItemDto> Items);
public record ExecutionItemDto(Guid Id, ExecutionItemType Type, string Title, Guid? AssigneeMemberId, bool IsSelected, Guid? ResultingEntityId);

public class RequestCommandHandlers :
    IRequestHandler<CreateRequestCommand, RequestDto>,
    IRequestHandler<UpdateDraftRequestCommand, RequestDto>,
    IRequestHandler<SubmitRequestCommand, RequestDto>,
    IRequestHandler<AskQuestionCommand, RequestDto>,
    IRequestHandler<AnswerQuestionCommand, RequestDto>,
    IRequestHandler<ApproveRequestCommand, RequestDto>,
    IRequestHandler<DenyRequestCommand, RequestDto>,
    IRequestHandler<CancelRequestCommand, RequestDto>,
    IRequestHandler<GetRequestQuery, RequestDto>,
    IRequestHandler<GetMyRequestsQuery, List<RequestDto>>,
    IRequestHandler<GetApprovalQueueQuery, List<RequestDto>>,
    IRequestHandler<GetRequestHistoryQuery, List<RequestHistoryDto>>,
    IRequestHandler<GetRequestTypesQuery, List<RequestTypeDto>>,
    IRequestHandler<EvaluatePolicyQuery, PolicyEvaluationResult>,
    IRequestHandler<OverridePolicyCommand, RequestDto>,
    IRequestHandler<GenerateExecutionPlanCommand, ExecutionPlanDto>,
    IRequestHandler<CommitExecutionPlanCommand, ExecutionPlanDto>
{
    private readonly IFamilyOsDbContext _db;
    private readonly ICurrentUserService _current;

    public RequestCommandHandlers(IFamilyOsDbContext db, ICurrentUserService current)
    {
        _db = db;
        _current = current;
    }

    public async Task<RequestDto> Handle(CreateRequestCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAuth();
        var request = Request.Create(_current.FamilyId!.Value, _current.MemberId!.Value,
            cmd.Type, cmd.Title, cmd.Answers, cmd.Amount, cmd.NeededBy);
        _db.Requests.Add(request);
        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<RequestDto> Handle(UpdateDraftRequestCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAuth();
        var request = await GetRequest(cmd.RequestId, ct);
        request.UpdateDraft(
            _current.MemberId!.Value,
            title: cmd.Title,
            answers: cmd.Answers,
            amount: cmd.Amount,
            neededBy: cmd.NeededBy);
        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<RequestDto> Handle(SubmitRequestCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        var request = await GetRequest(cmd.RequestId, ct);
        request.Submit(_current.MemberId!.Value);

        var approvers = await _db.FamilyMembers.AsNoTracking()
            .Where(m => m.FamilyId == _current.FamilyId
                        && m.IsActive
                        && m.Id != request.RequesterMemberId
                        && (m.Role == FamilyRole.Owner || m.Role == FamilyRole.Adult))
            .Select(m => m.Id)
            .ToListAsync(ct);

        foreach (var mid in approvers)
        {
            _db.Notifications.Add(Notification.Create(
                _current.FamilyId!.Value,
                mid,
                NotificationType.RequestSubmitted,
                $"Request needs review: {request.Title}",
                $"{request.Type} submitted and waiting for approval.",
                request.Id,
                "Request"));
        }

        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<RequestDto> Handle(AskQuestionCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAdult();
        var request = await GetRequest(cmd.RequestId, ct);
        request.AskQuestion(_current.MemberId!.Value, cmd.QuestionText);

        if (request.RequesterMemberId != _current.MemberId)
        {
            _db.Notifications.Add(Notification.Create(
                _current.FamilyId!.Value,
                request.RequesterMemberId,
                NotificationType.RequestQuestionAsked,
                $"Question on: {request.Title}",
                cmd.QuestionText.Length > 120 ? cmd.QuestionText[..117] + "…" : cmd.QuestionText,
                request.Id,
                "Request"));
        }

        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<RequestDto> Handle(AnswerQuestionCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        var request = await GetRequest(cmd.RequestId, ct);
        request.AnswerQuestion(_current.MemberId!.Value, cmd.QuestionId, cmd.Answer);
        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<RequestDto> Handle(ApproveRequestCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAdult();
        var request = await GetRequest(cmd.RequestId, ct);
        request.Approve(_current.MemberId!.Value, cmd.Conditional);

        if (request.RequesterMemberId != _current.MemberId)
        {
            var label = cmd.Conditional ? "Conditionally approved" : "Approved";
            _db.Notifications.Add(Notification.Create(
                _current.FamilyId!.Value,
                request.RequesterMemberId,
                NotificationType.RequestApproved,
                $"{label}: {request.Title}",
                cmd.Conditional
                    ? "Your request was conditionally approved — check conditions."
                    : "Your request was approved.",
                request.Id,
                "Request"));
        }

        if (!cmd.Conditional)
        {
            EnqueueProcurementFromRequest(request);
            ScheduleCalendarFromRequest(request);
        }

        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<RequestDto> Handle(DenyRequestCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAdult();
        var request = await GetRequest(cmd.RequestId, ct);
        request.Deny(_current.MemberId!.Value, cmd.Reason);

        if (request.RequesterMemberId != _current.MemberId)
        {
            _db.Notifications.Add(Notification.Create(
                _current.FamilyId!.Value,
                request.RequesterMemberId,
                NotificationType.RequestDenied,
                $"Denied: {request.Title}",
                string.IsNullOrWhiteSpace(cmd.Reason) ? "Your request was denied." : cmd.Reason,
                request.Id,
                "Request"));
        }

        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<RequestDto> Handle(CancelRequestCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAuth();
        var request = await GetRequest(cmd.RequestId, ct);
        var isOwner = _current.Role == FamilyRole.Owner;
        request.Cancel(_current.MemberId!.Value, isOwner, cmd.Reason);
        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<RequestDto> Handle(GetRequestQuery query, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        var request = await GetRequest(query.RequestId, ct);
        return await ToDto(request, ct);
    }

    public async Task<List<RequestDto>> Handle(GetMyRequestsQuery query, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAuth();
        var list = await _db.Requests.AsNoTracking()
            .Include(r => r.PendingQuestions)
            .Where(r => r.FamilyId == _current.FamilyId && r.RequesterMemberId == _current.MemberId)
            .OrderByDescending(r => r.CreatedAtUtc)
            .ToListAsync(ct);
        var result = new List<RequestDto>();
        foreach (var r in list) result.Add(await ToDto(r, ct));
        return result;
    }

    public async Task<List<RequestDto>> Handle(GetApprovalQueueQuery query, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAdult();
        var list = await _db.Requests.AsNoTracking()
            .Include(r => r.PendingQuestions)
            .Where(r => r.FamilyId == _current.FamilyId &&
                        (r.Status == RequestStatus.Submitted
                         || r.Status == RequestStatus.UnderReview
                         || r.Status == RequestStatus.WaitingForInformation))
            .OrderBy(r => r.CreatedAtUtc)
            .ToListAsync(ct);
        var result = new List<RequestDto>();
        foreach (var r in list) result.Add(await ToDto(r, ct));
        return result;
    }

    public async Task<List<RequestHistoryDto>> Handle(GetRequestHistoryQuery query, CancellationToken ct)
    {
        var request = await GetRequest(query.RequestId, ct);
        return request.History
            .OrderBy(h => h.TimestampUtc)
            .Select(h => new RequestHistoryDto(h.Id, h.Status, h.ActorMemberId, h.Detail, h.TimestampUtc))
            .ToList();
    }

    public async Task<List<RequestTypeDto>> Handle(GetRequestTypesQuery query, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        var types = await _db.RequestTypeDefinitions.AsNoTracking()
            .Where(t => t.IsEnabled)
            .OrderBy(t => t.SortOrder)
            .ToListAsync(ct);
        return types.Select(t => new RequestTypeDto(t.Id, t.Code, t.Name, t.Description, t.GetQuestions())).ToList();
    }

    public async Task<PolicyEvaluationResult> Handle(EvaluatePolicyQuery query, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        var request = await GetRequest(query.RequestId, ct);
        var policy = await _db.ApprovalPolicies.AsNoTracking()
            .Where(p => p.FamilyId == _current.FamilyId && p.IsActive &&
                        (p.AppliesToType == null || p.AppliesToType == request.Type))
            .OrderByDescending(p => p.Priority)
            .FirstOrDefaultAsync(ct);

        if (policy == null)
            return PolicyEvaluationResult.RequireApproval("No policy configured; require adult approval.");

        return policy.Evaluate(_current.Role ?? FamilyRole.Child, _current.MemberId!.Value,
            request.RequesterMemberId, request.Amount, request.Type);
    }

    public async Task<RequestDto> Handle(OverridePolicyCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAuth();
        if (_current.Role != FamilyRole.Owner)
            throw new ForbiddenException("Only the family Owner can override policy.");

        var request = await GetRequest(cmd.RequestId, ct);
        if (request.Status is RequestStatus.Completed or RequestStatus.Cancelled or RequestStatus.Denied)
            throw new InvalidOperationException($"Cannot override a request in status {request.Status}.");

        var policy = await _db.ApprovalPolicies.AsNoTracking()
            .Where(p => p.FamilyId == _current.FamilyId && p.IsActive &&
                        (p.AppliesToType == null || p.AppliesToType == request.Type))
            .OrderByDescending(p => p.Priority)
            .FirstOrDefaultAsync(ct);

        var evaluation = policy == null
            ? PolicyEvaluationResult.RequireApproval("No policy configured.")
            : policy.Evaluate(_current.Role ?? FamilyRole.Owner, _current.MemberId!.Value,
                request.RequesterMemberId, request.Amount, request.Type);

        var original = evaluation.RequiresOwner
            ? $"RequiresOwner: {evaluation.Explanation}"
            : evaluation.IsAllowed
                ? $"Allowed: {evaluation.Explanation}"
                : evaluation.AutoApproved
                    ? $"AutoApproved: {evaluation.Explanation}"
                    : $"Denied/Blocked: {evaluation.Explanation}";

        var decision = cmd.Approve
            ? (cmd.Conditional ? "ConditionallyApproved" : "Approved")
            : "Denied";

        _db.PolicyOverrides.Add(PolicyOverride.Create(
            _current.FamilyId!.Value,
            request.Id,
            _current.MemberId!.Value,
            original,
            decision,
            cmd.Reason));

        if (cmd.Approve)
        {
            request.Approve(_current.MemberId!.Value, cmd.Conditional);
            if (!cmd.Conditional)
            {
                EnqueueProcurementFromRequest(request);
                ScheduleCalendarFromRequest(request);
            }
        }
        else
            request.Deny(_current.MemberId!.Value, cmd.Reason ?? "Owner policy override — denied");

        if (request.RequesterMemberId != _current.MemberId)
        {
            _db.Notifications.Add(Notification.Create(
                _current.FamilyId!.Value,
                request.RequesterMemberId,
                cmd.Approve ? NotificationType.RequestApproved : NotificationType.RequestDenied,
                cmd.Approve ? $"Approved (owner override): {request.Title}" : $"Denied (owner override): {request.Title}",
                cmd.Reason ?? (cmd.Approve ? "Owner overrode policy and approved." : "Owner overrode policy and denied."),
                request.Id,
                "Request"));
        }

        await _db.SaveChangesAsync(ct);
        return await ToDto(request, ct);
    }

    public async Task<ExecutionPlanDto> Handle(GenerateExecutionPlanCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAdult();
        var request = await GetRequest(cmd.RequestId, ct);
        if (request.Status is not (RequestStatus.Approved or RequestStatus.ConditionallyApproved or RequestStatus.Executable))
            throw new BusinessRuleException("Request must be approved before generating a plan.");

        var plan = ExecutionPlan.Create(_current.FamilyId!.Value, request.Id, _current.MemberId!.Value);
        plan.AddItem(ExecutionItemType.Task, $"Execute: {request.Title}", _current.MemberId);
        if (request.Type == RequestTypeCode.Ride || request.NeededByUtc.HasValue)
            plan.AddItem(ExecutionItemType.CalendarEvent, request.Title, _current.MemberId);

        _db.ExecutionPlans.Add(plan);
        request.LinkExecutionPlan(plan.Id);
        await _db.SaveChangesAsync(ct);
        return ToPlanDto(plan);
    }

    public async Task<ExecutionPlanDto> Handle(CommitExecutionPlanCommand cmd, CancellationToken ct)
    {
        await _current.EnsureLoadedAsync(ct);
        EnsureAdult();
        var plan = await _db.ExecutionPlans
            .Include(p => p.Items)
            .FirstOrDefaultAsync(p => p.Id == cmd.PlanId && p.FamilyId == _current.FamilyId, ct)
            ?? throw new NotFoundException("ExecutionPlan", cmd.PlanId);

        if (cmd.DeselectedItemIds != null)
            foreach (var id in cmd.DeselectedItemIds)
                plan.RemoveItem(id);

        plan.Commit(_current.MemberId!.Value);

        var request = await _db.Requests.FirstOrDefaultAsync(r => r.Id == plan.RequestId, ct);
        foreach (var item in plan.Items.Where(i => i.IsSelected))
        {
            switch (item.Type)
            {
                case ExecutionItemType.Task:
                {
                    var task = TaskItem.Create(
                        plan.FamilyId,
                        item.Title,
                        _current.MemberId!.Value,
                        description: request is null ? null : $"Created from request: {request.Title}",
                        dueDate: request?.NeededByUtc);
                    task.Assign(item.AssigneeMemberId ?? _current.MemberId!.Value, _current.MemberId!.Value);
                    _db.Tasks.Add(task);
                    item.LinkResult(task.Id);
                    break;
                }
                case ExecutionItemType.CalendarEvent:
                {
                    var start = request?.NeededByUtc ?? DateTime.UtcNow.AddHours(2);
                    var ev = CalendarEvent.Create(
                        plan.FamilyId,
                        item.Title,
                        start,
                        _current.MemberId!.Value,
                        endUtc: start.AddHours(1),
                        allDay: false,
                        location: null,
                        linkedTaskId: null,
                        linkedRequestId: plan.RequestId);
                    _db.CalendarEvents.Add(ev);
                    item.LinkResult(ev.Id);
                    break;
                }
                case ExecutionItemType.ProcurementItem:
                {
                    var procurementItem = ProcurementItem.Create(
                        plan.FamilyId,
                        item.Title,
                        _current.MemberId!.Value,
                        requestId: plan.RequestId,
                        category: "Purchase",
                        quantity: 1);
                    _db.ProcurementItems.Add(procurementItem);
                    item.LinkResult(procurementItem.Id);
                    break;
                }
            }
        }

        await _db.SaveChangesAsync(ct);
        return ToPlanDto(plan);
    }

    private void ScheduleCalendarFromRequest(Request request)
    {
        if (request.Type is not (RequestTypeCode.Ride or RequestTypeCode.School or RequestTypeCode.Medical))
            return;

        var answers = request.GetAnswers();
        string? location = null;
        if (answers.TryGetValue("location", out var loc) && loc is not null)
            location = loc.ToString();
        else if (answers.TryGetValue("where", out var wh) && wh is not null)
            location = wh.ToString();
        else if (answers.TryGetValue("pickup", out var pu) && pu is not null)
            location = pu.ToString();

        var start = request.NeededByUtc ?? DateTime.UtcNow.AddHours(2);
        if (answers.TryGetValue("when", out var whenObj) && whenObj is not null
            && DateTime.TryParse(whenObj.ToString(), out var parsed))
            start = parsed.Kind == DateTimeKind.Unspecified
                ? DateTime.SpecifyKind(parsed, DateTimeKind.Utc)
                : parsed.ToUniversalTime();

        var end = start.AddHours(request.Type == RequestTypeCode.Ride ? 1 : 2);
        var titlePrefix = request.Type switch
        {
            RequestTypeCode.Ride => "Ride: ",
            RequestTypeCode.School => "School: ",
            RequestTypeCode.Medical => "Medical: ",
            _ => ""
        };

        _db.CalendarEvents.Add(CalendarEvent.Create(
            request.FamilyId,
            titlePrefix + request.Title,
            start,
            _current.MemberId!.Value,
            endUtc: end,
            allDay: false,
            location: location,
            linkedTaskId: null,
            linkedRequestId: request.Id));

        if (request.RequesterMemberId != _current.MemberId)
        {
            _db.Notifications.Add(Notification.Create(
                request.FamilyId,
                request.RequesterMemberId,
                NotificationType.CalendarReminder,
                $"On calendar: {request.Title}",
                $"Scheduled for {start:u}" + (location is null ? "" : $" · {location}"),
                request.Id,
                "Calendar"));
        }
    }

    private void EnqueueProcurementFromRequest(Request request)
    {
        if (request.Type is not (RequestTypeCode.Grocery or RequestTypeCode.Purchase or RequestTypeCode.SnackFood))
            return;

        var category = request.Type switch
        {
            RequestTypeCode.Grocery => "Grocery",
            RequestTypeCode.SnackFood => "Snack",
            _ => "Purchase"
        };

        var answers = request.GetAnswers();
        string? store = null;
        if (answers.TryGetValue("store", out var storeObj) && storeObj is not null)
            store = storeObj.ToString();
        else if (answers.TryGetValue("preferredStore", out var ps) && ps is not null)
            store = ps.ToString();

        var itemNames = new List<string>();
        if (answers.TryGetValue("items", out var itemsObj) && itemsObj is not null)
        {
            var raw = itemsObj.ToString() ?? "";
            foreach (var part in raw.Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                if (!string.IsNullOrWhiteSpace(part))
                    itemNames.Add(part);
        }

        if (itemNames.Count == 0)
        {
            foreach (var part in request.Title.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                if (!string.IsNullOrWhiteSpace(part))
                    itemNames.Add(part);
        }

        if (itemNames.Count == 0)
            itemNames.Add(request.Title);

        for (var i = 0; i < itemNames.Count; i++)
        {
            var name = itemNames[i];
            var est = i == 0 ? request.Amount : null;
            _db.ProcurementItems.Add(ProcurementItem.Create(
                request.FamilyId,
                name,
                _current.MemberId!.Value,
                requestId: request.Id,
                category: category,
                quantity: 1,
                estimatedPrice: est,
                preferredStore: store));
        }

        if (request.RequesterMemberId != _current.MemberId)
        {
            _db.Notifications.Add(Notification.Create(
                request.FamilyId,
                request.RequesterMemberId,
                NotificationType.ProcurementChanged,
                $"On shopping list: {request.Title}",
                $"{itemNames.Count} item(s) added to the family procurement queue.",
                request.Id,
                "Procurement"));
        }
    }

    private async Task<Request> GetRequest(Guid id, CancellationToken ct)
    {
        EnsureAuth();
        return await _db.Requests
            .Include(r => r.History)
            .Include(r => r.PendingQuestions)
            .FirstOrDefaultAsync(r => r.Id == id && r.FamilyId == _current.FamilyId, ct)
            ?? throw new NotFoundException("Request", id);
    }

    private void EnsureAuth()
    {
        if (!_current.IsAuthenticated || !_current.FamilyId.HasValue || !_current.MemberId.HasValue)
            throw new ForbiddenException("Not authenticated.");
    }

    private void EnsureAdult()
    {
        EnsureAuth();
        if (_current.Role is not (FamilyRole.Owner or FamilyRole.Adult))
            throw new ForbiddenException("Only Adults and Owners can perform this action.");
    }

    private async Task<RequestDto> ToDto(Request r, CancellationToken ct)
    {
        var name = await _db.FamilyMembers.AsNoTracking()
            .Where(m => m.Id == r.RequesterMemberId)
            .Select(m => m.DisplayName)
            .FirstOrDefaultAsync(ct) ?? "Member";

        var questions = r.PendingQuestions
            .Select(q => new PendingQuestionDto(q.Id, q.QuestionText, q.IsAnswered, q.AnswerText))
            .ToList();
        return new RequestDto(r.Id, r.Type, r.Status, r.Title, r.Summary, r.Amount, r.NeededByUtc,
            r.RequesterMemberId, name, r.CurrentApproverMemberId, r.DenialReason, r.CreatedAtUtc, r.GetAnswers(),
            r.ExecutionPlanId, questions);
    }

    private static ExecutionPlanDto ToPlanDto(ExecutionPlan plan) =>
        new(plan.Id, plan.RequestId, plan.Status,
            plan.Items.Select(i => new ExecutionItemDto(i.Id, i.Type, i.Title, i.AssigneeMemberId, i.IsSelected, i.ResultingEntityId)).ToList());
}
