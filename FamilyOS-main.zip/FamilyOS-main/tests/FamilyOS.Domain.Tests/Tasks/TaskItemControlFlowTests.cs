using FamilyOS.Domain.Common;
using FamilyOS.Domain.Tasks;
using FluentAssertions;

namespace FamilyOS.Domain.Tests.Tasks;

public class TaskItemControlFlowTests
{
    private static readonly Guid FamilyId = Guid.NewGuid();
    private static readonly Guid Creator = Guid.NewGuid();
    private static readonly Guid Assignee = Guid.NewGuid();

    private static TaskItem AcceptedTask()
    {
        var t = TaskItem.Create(FamilyId, "Chore", Creator, category: "home");
        t.Assign(Assignee, Creator);
        t.Accept(Assignee);
        return t;
    }

    private static TaskItem AssignedTask()
    {
        var t = TaskItem.Create(FamilyId, "Chore", Creator, category: "home");
        t.Assign(Assignee, Creator);
        return t;
    }

    [Fact]
    public void Pause_and_Resume()
    {
        var t = AcceptedTask();
        t.Start(Assignee);
        t.Status.Should().Be(FamilyTaskStatus.InProgress);

        t.Pause(Assignee);
        t.Status.Should().Be(FamilyTaskStatus.Paused);
        t.TimeSegments.Should().OnlyContain(s => s.EndedAtUtc.HasValue);

        t.Resume(Assignee);
        t.Status.Should().Be(FamilyTaskStatus.InProgress);
        t.TimeSegments.Should().Contain(s => !s.EndedAtUtc.HasValue);
    }


    [Fact]
    public void Only_assignee_can_pause_or_complete()
    {
        var t = AcceptedTask();
        t.Start(Assignee);

        var pause = () => t.Pause(Creator);
        pause.Should().Throw<UnauthorizedAccessException>();

        var complete = () => t.Complete(Creator);
        complete.Should().Throw<UnauthorizedAccessException>();

        t.Pause(Assignee);
        t.Complete(Assignee);
        t.Status.Should().Be(FamilyTaskStatus.Completed);
    }

    [Fact]
    public void SetPriority_and_UpdateDetails()
    {
        var t = TaskItem.Create(FamilyId, "Old", Creator);
        t.SetPriority(TaskPriority.High);
        t.Priority.Should().Be(TaskPriority.High);
        t.UpdateDetails("New title", "desc", "chores");
        t.Title.Should().Be("New title");
        t.Description.Should().Be("desc");
        t.Category.Should().Be("chores");
    }

    [Fact]
    public void SetDueDate_and_PlannedTimes()
    {
        var t = TaskItem.Create(FamilyId, "Timed", Creator);
        var due = DateTime.UtcNow.AddDays(2);
        t.SetDueDate(due);
        t.DueDate.Should().Be(due);

        var start = DateTime.UtcNow.AddHours(1);
        var end = start.AddHours(2);
        t.SetPlannedTimes(start, end, estimatedMinutes: 120);
        t.PlannedStartUtc.Should().Be(start);
        t.PlannedEndUtc.Should().Be(end);
        t.EstimatedMinutes.Should().Be(120);
    }

    [Fact]
    public void Defer_requires_assignee_and_an_accepted_task()
    {
        var t = AssignedTask();
        var until = DateTime.UtcNow.AddDays(3);
        var notAccepted = () => t.Defer(Assignee, until, "Busy");
        notAccepted.Should().Throw<InvalidOperationException>();
        t.Accept(Assignee);
        var notAssignee = () => t.Defer(Creator, until, "Busy");
        notAssignee.Should().Throw<UnauthorizedAccessException>();
        t.Defer(Assignee, until, "Busy");
        t.Status.Should().Be(FamilyTaskStatus.Deferred);
        t.DueDate.Should().Be(until);
    }

    [Fact]
    public void Reassign_from_Assigned()
    {
        var t = AssignedTask();
        var other = Guid.NewGuid();
        t.Reassign(other, Creator);
        t.AssigneeMemberId.Should().Be(other);
        t.Status.Should().Be(FamilyTaskStatus.Reassigned);
    }

    [Fact]
    public void Skip_from_Assigned()
    {
        var t = AssignedTask();
        t.Skip(Creator, "Not needed");
        t.Status.Should().Be(FamilyTaskStatus.Skipped);
    }

    [Fact]
    public void Cancel_from_Created()
    {
        var t = TaskItem.Create(FamilyId, "Cancel me", Creator);
        t.Cancel(Creator, "Changed mind");
        t.Status.Should().Be(FamilyTaskStatus.Cancelled);
    }
}